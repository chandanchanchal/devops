using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ServiceBus.Messaging;
using Microsoft.ServiceBus;

namespace ServiceBusconnect
{
	class Program
	{
		static void Main(string[] args)
		{
			var conn = "Endpoint=sb://chandanchanchal.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=I2ilQvQOrdPdaaULYaD5WS5fvgZUIGLygh91+Jy+ir0=";
			var queue = "chandanpaymentsqueue";
			var topic = "fromlocal";
			var nsm = NamespaceManager.CreateFromConnectionString(conn);
			var topicclient = TopicClient.CreateFromConnectionString(conn,topic);
			
			if (nsm.SubscriptionExists(topic, "AllMessages") == false)
			{
				nsm.CreateSubscription(topic, "AllMessages");
			}
			var subclient = SubscriptionClient.CreateFromConnectionString(conn, topic, "AllMessages");

			var client = QueueClient.CreateFromConnectionString(conn,queue);
			var msg = new BrokeredMessage("Hello1");
			client.Send(msg);			
			WriteReadTopic(topicclient);
			ReadTopic(subclient);
			Console.ReadKey();
		}

		static void WriteReadTopic(TopicClient client)
		{
			
			var msg = new BrokeredMessage("This is another topic Message");
			client.Send(msg);

		}

		static void ReadTopic(SubscriptionClient client)
		{
			OnMessageOptions option = new OnMessageOptions();
			option.AutoComplete = false;
			client.OnMessage(message =>
			{
				Console.WriteLine(" Message: " + message.GetBody<string>());
				message.Complete();
			},option);


		}

	}
}
